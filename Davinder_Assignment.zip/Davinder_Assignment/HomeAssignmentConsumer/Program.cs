﻿using HomeAssignmentBAL;
using HomeAssignmentBAL.DomainModels;
using System;

namespace HomeAssignmentConsumer
{
    class Program
    {
        static void Main(string[] args)
        {
            BestDealFinder dealFinder = new BestDealFinder();
            var bestDealForShipping = dealFinder.GetBestShippingDeal(new ShippingModel()).GetAwaiter().GetResult();

            if (bestDealForShipping != null)
            {
               Console.WriteLine($"Here is the best deal provided by {bestDealForShipping.Name} : ${bestDealForShipping.Amount}");
            }
        }
    }
}
