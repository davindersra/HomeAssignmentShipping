﻿using HomeAssignmentBAL.Base;
using HomeAssignmentBAL.DomainModels;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace HomeAssignmentBAL.Interfaces
{
    public class GenericApiResponseProvider : ThirdPartServiceRequestHandler, IGenericThirdPartyApiProvider
    {
        /// <summary>
        /// This method will be used to get shipping costs from associated partners
        /// </summary>
        /// <returns></returns>
        public async Task<dynamic> GetShippingCostsFromShippingProviders(string Providername,string Token,string Url)
        {
            //Configure the http client as per the provider here like
            //if (Providername == "Bluedard"//add blueDard into enums as well)
                //{
                ///HttpClient.DefaultRequestHeaders
         
            //}
            
            HttpResponseMessage response = HttpClient.GetAsync(Url).Result;

            if (response.IsSuccessStatusCode)
            {
                var shippingCostData = await response.Content.ReadAsStringAsync();
                var allShippingCosts = JsonConvert.DeserializeObject<IEnumerable<dynamic>>(shippingCostData);

                return allShippingCosts;
            }
            return null;
       
        }
    }
}
