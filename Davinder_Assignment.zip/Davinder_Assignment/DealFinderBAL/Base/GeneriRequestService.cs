﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace HomeAssignmentBAL.Base
{
   
    public  class ThirdPartServiceRequestHandler
    {
        HttpClient _httpClient;
        public ThirdPartServiceRequestHandler()
        {
            _httpClient = new HttpClient();
        }
        // below httpClient will be accessed by the consumer class
        public HttpClient HttpClient => _httpClient;


    }
}
