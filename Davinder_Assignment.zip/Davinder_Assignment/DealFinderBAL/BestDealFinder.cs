﻿using HomeAssignmentBAL.DomainModels;
using HomeAssignmentBAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeAssignmentBAL
{
    public class BestDealFinder
    {
        ResponseModel returnModel;
        public BestDealFinder()
        {
            returnModel = new ResponseModel();
        }
        /// <summary>
        ///Use to get the lowest cost by ordering
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private ResponseModel FindLowestShippingCost(List<dynamic> data)
        {
            if (data.Count() > 0)
            {
                var lowestCost = data.OrderBy(x => x.Amount).FirstOrDefault();
                return lowestCost;
            }
            else
            {
                return new ResponseModel();
            }
        }
         
        public async Task<ResponseModel> GetBestShippingDeal(ShippingModel shippingDetails)
        {
            var providers = new GenericApiResponseProvider();
            List<dynamic> allResponses = new List<dynamic>();
            //Call all providers and capture the response in GenericResponseModel and then parse into our internal model
             allResponses.Add(await providers.GetShippingCostsFromShippingProviders("BlueDart", "", ""));
            //allResponses.Add(await providers.GetShippingCostsFromShippingProviders("SpeedWay", "", ""));
            //allResponses.Add(await providers.GetShippingCostsFromShippingProviders("ikKart", "", ""));
         

             //One way of doing this is create a private method here and then try parse all responses into ResponseModelObject 
             //and then pass to FindLowestShippingCost

            var lowestDeal = FindLowestShippingCost(allResponses);
            return lowestDeal;




        }
    }
}
