﻿namespace HomeAssignmentBAL.DomainModels
{
    public class GenericDimension
    {
    }
}