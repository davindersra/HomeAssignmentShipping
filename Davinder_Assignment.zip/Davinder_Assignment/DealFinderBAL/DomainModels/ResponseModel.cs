﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomeAssignmentBAL.DomainModels
{
  public  class ResponseModel: GenericResponseModel<dynamic>
    {
        public bool Status { get; set; }
        public string Name { get; set; }
        public decimal Amount { get; set; }
        public ResponseModel()
        {
            this.Status = false;
            this.Name = string.Empty;
            this.Amount = 0;
        }
    }

    public class GenericResponseModel<T>
    {
        public T ResponseModel { get; set; }
    }
}
