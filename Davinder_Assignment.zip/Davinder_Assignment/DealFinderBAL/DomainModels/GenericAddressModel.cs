﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomeAssignmentBAL.DomainModels
{
   public class GenericAddressModel
    {
        public string PrimaryAddress { get; set; }
        public string SecondaryAddress  { get; set; }
        public string Country { get; set; }
        public string State { get; set; } 
        public string City { get; set; }
        public string ZipCode { get; set; }
        
    }
}
