﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomeAssignmentBAL.DomainModels
{
   public class ShippingModel
    {
        public ShippingModel()
        {
            ContactAddress = new GenericAddressModel();
            WarehouseAddress = new GenericAddressModel();
            Dimensions = new List<GenericDimentions>();
        } 
        public GenericAddressModel ContactAddress { get; set; }
       
        public GenericAddressModel WarehouseAddress { get; set; }

        public List<GenericDimentions> Dimensions { get; set; }
    }
}
