﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomeAssignmentBAL.DomainModels
{

    public class GenericDimentions
    {
        public decimal Length { get; set; }
        public decimal Width { get; set; }
    }
}
