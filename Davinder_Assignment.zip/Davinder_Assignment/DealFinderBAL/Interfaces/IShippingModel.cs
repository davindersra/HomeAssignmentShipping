﻿using HomeAssignmentBAL.DomainModels;

namespace HomeAssignmentBAL.Interfaces
{
    interface IShippingModel
    {
        GenericAddressModel ContactAddress { get; set; }
        GenericAddressModel WarehouseAddress { get; set; }
        GenericDimentions[] PackageDimensions { get; set; }

        //we can extend this later if required 
    }
}
