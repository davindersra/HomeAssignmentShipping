﻿using HomeAssignmentBAL.DomainModels;
using System.Threading.Tasks;

namespace HomeAssignmentBAL.Interfaces
{
    public interface IGenericThirdPartyApiProvider
    {
        Task<dynamic> GetShippingCostsFromShippingProviders(string Providername,string Token,string Url);
    }
}
