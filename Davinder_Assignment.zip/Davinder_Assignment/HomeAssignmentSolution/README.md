# HomeAssignment
shipping cost detail mock structure
