﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Xml;
using Newtonsoft.Json;

namespace HomeAssignment
{
    public class HomeController : ControllerBase
    {
        
        public HomeController()
        {
            httpClient = new HttpClient();
        }
     
    }
}
